**COMPANY NAME / LOGO**

WEEKLY ATTENDANCE SHEET

**WEEK 1**

| No. | Student’s Name, Surname | 01.09.26 No. of hours (online/offline) | 02.09.26 No. of hours (online/offline) | 03.09.26 No. of hours (online/offline) | 04.09.26 No. of hours (online/offline) | DAY 5 No. of hours (online/offline) | Weekly total hours + Company internship supervisor’s signature |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 |  | 6 hours online | 3 hours offline | Absent | … | … |  |
| 2 |  |  |  |  |  |  |  |
| 3 |  |  |  |  |  |  |  |
| 4 |  |  |  |  |  |  |  |
| 5 |  |  |  |  |  |  |  |

**Company stamp**