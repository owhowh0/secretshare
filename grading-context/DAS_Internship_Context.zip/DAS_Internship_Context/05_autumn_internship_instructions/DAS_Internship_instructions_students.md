> Source: Extracted text of DAS_Internship_instructions_students-f.pdf (original PDF kept alongside this file, unedited).

# AUTUMN INTERNSHIP – INFORMATION AND REQUIREMENTS

Dear Students,

As you begin your Autumn Internship, please carefully follow the information below.

The internship is part of the Development of Secure Applications (DAS) course. During the internship, you will work in teams with company mentors on a secure application project. After returning to university, you will continue your work within the separate PBL course, according to the PBL schedule and requirements.

| Title | Description | Responsible |
|---|---|---|
| **Internship Overview** | Period: September 01–6 (7 weeks, 6 hours/day). Project: Development of Secure Applications (DAS). Students work in teams with company mentors on a secure application project and develop an initial MVP. | Students / Company Mentors / Internship Coordinators |
| **ELSE** | All guidelines, templates, deadlines, and announcements are available on ELSE. Courses: https://else.fcim.utm.md/course/view.php?id=3702 — FAF241_PP, FAF242_PP, FAF243_PP. Check ELSE regularly. | Students |
| **Internship Contract** | Collect 2 original copies once they are stamped by TUM. After signing and stamping, one copy remains with the company and one is returned to the faculty. Keep a personal copy as well. | Each student |
| **Weekly Activity Report** | Complete and upload one report every week on ELSE. These reports contribute to the Internship Log Book and report. | Each student |
| **Weekly Attendance Sheet** | The Team Leader presents the sheet to the company mentor weekly. The mentor records hours, online/offline activity, or absence and validates the sheet with a signature and company stamp, where applicable. | Team Leader / Company Mentor |
| **Internship Log Book** | Complete the Log Book electronically throughout the internship. At the end, finalize and print it and present it to the company mentor. | Each student |
| **Company Evaluation** | The company mentor completes the final evaluation in the Log Book, including the grade, signature, and company stamp. This grade is part of the internship assessment. | Company Mentor |
| **Internship Report** | Prepare the report according to the requirements on ELSE. | Each team |
| **Midterm 1** | Week 5, after returning to university. During the first PBL session, each team will make a PPT presentation of the internship project. The PBL mentors, together with the University Internship Coordinators, will evaluate and grade the presentation, individual contribution, and internship report. | PBL Mentors / University Internship Coordinators |
| **Midterm 2 – Internship Evaluation** | According to the university schedule. The evaluation will be based on the Company Mentor's grade recorded in the Internship Log Book, including the grade in numbers and letters, mentor's signature, and company stamp, where applicable. | Company Mentor / Evaluation Team |
| **Final Exam** | End of the semester. The final evaluation will include a short team interview and individual reflections. The Internship Log Book, Weekly Activity Reports, and Attendance Sheets will also be reviewed as part of the final assessment. | Entire Evaluation Team |
| **Online Progress Meetings** | An online meeting every two weeks will be organized to answer questions, discuss difficulties, and monitor project progress. | Internship Coordinators / Students |
| **Communication & Difficulties** | Maintain professional communication with your Company Mentor and Internship Coordinator. Report any problems immediately. | Students |
| **Company Feedback & Visits** | Take seriously feedback concerning attendance, punctuality, engagement, responsibility, technical work, and teamwork. Internship supervisors may visit companies to monitor progress. | Students / Company Mentors / Supervisors |
| **ELSE – Regular Monitoring** | Check ELSE regularly for requirements, templates, deadlines, evaluation information, and announcements. | Students |
| **Important: DAS Internship and PBL** | The DAS Internship and DAS PBL are separate courses/components. After returning to university, students will continue the project within the PBL course, according to its schedule and requirements. A separate PBL Report is required. Relevant material from the DAS internship may be reused, but the Internship Report and PBL Report are different documents and must follow the requirements of their respective courses. | Students / PBL Mentors |
| **Final Checklist** | Make sure you: complete the Contract, Weekly Reports, Attendance Sheet and Log Book; attend progress meetings; check ELSE; meet all evaluation deadlines; and complete the separate PBL requirements after returning to university. | Each student |

We wish you a successful and productive internship!
