> Source: Pasted directly by the user (originally from the ELSE platform / else.fcim.utm.md course pages). Reproduced verbatim, unedited.

This internship, as part of the PBL course, serves as the initial phase where you focus on conducting in-depth research and designing the system for your project. During this process, you will gather the necessary information, analyze the problem, and create a solid plan for your solution. Afterward, you will continue the project in the PBL course, where you'll have the opportunity to implement your design, develop the final product, and refine your system into a functional application. Together, the internship and the PBL course form a cohesive process, transitioning from research and planning to practical implementation and finalization of your application.
During your internship, you must work as a team to develop a Minimum Viable Product (MVP). Your team should collaborate with mentors to select an appropriate project idea, then conduct a detailed domain analysis, identify security concerns that have to be  addressed before beginning development. You'll also need to choose a suitable technology stack, define the project structure, and clearly define team roles and responsibilities. Additionally, select potential solutions for the identified security concerns.

* Project topic: Development of Secure Applications
* Duration: 4 weeks - 01-26  September
* Daily hours: 6 hours/day
* Credits: 8 ECTS
* Form of evaluation: 2 Midterms + Exam at the end of the semester
* 3rd year of studies

[General objectives:](https://else.fcim.utm.md/course/section.php?id=12746)

   1. Apply theoretical knowledge into practice.
   2. Develop practical and technical skills relevant to their field.
   3. Gain exposure to the professional work environment.
   4. Build professional relationships and networks.
These objectives are meant to prepare students for their future careers, with a clearer understanding of the IT field and a stronger set of skills and experiences to draw upon.

Ghidul metodic este elaborat în baza Ghidului “Organizarea şi desfăşurarea stagiilor de practică” şi al Regulamentului privind organizarea şi desfăşurarea stagiilor de practică a studenţilor UTM. Ghidul metodic este elaborat în acord cu legislaţia în vigoare: 
   * Legea învăţământului (nr. 547-XIII din 21 iulie 1995);
   * Legea nr 71-XVI din 05 mai 2005 cu privire la modificarea şi completarea Legii învăţământului nr. 547-XIII din 21 iulie 1995 privind organizarea învăț ământului superior pe cicluri;
   * Plan-cadru provizoriu pentru ciclul I (studii superioare de licenţă), aprobat prin Ordinul nr. 22 din iulie 2005 al Ministerului Educaţiei, Tineretului şi Ştiin ţei al Republicii Moldova;
   * Regulamentul de organizare şi desfăşurare a procesului didactic în instituţiile de învăţământ superior universitar din Republica Moldova, aprobat prin Hotărârea Consiliului Ministerului Învă ţământului, Tineretului şi Sportului (nr. 1.3.1. din 31 martie 1997);
   * Anexa la Ordinul nr. 220 din 14 aprilie 2010 Cu privire la aprobarea modificărilor şi completărilor ce se operează în Ghidul de implementare a Sistemului Naţional de Credite de Studiu;
   * Regulamentul de organizare şi desfăşurare a procesului didactic în Universitatea Tehnică a Moldovei, aprobat prin Hotărârea Senatului UTM;
   * Regulamentul de organizare şi desfăşurare a procesului didactic la învăţământul superior de licenţă cu frecvenţ a redusă în Universitatea Tehnică a Moldovei, aprobat prin Hotărârea Senatului UTM;
   * Regulamentul privind organizarea şi desfăşurarea stagiilor de practică a studenţilor la Universitatea Tehnică a Moldovei aprobat prin Hotărârea Senatului UTM din 30 noiembrie 2010.

Organizarea stagiului de practică:
   * Durata stagiului de practică este specificată în planul de învăţământ:
   * Calendarul activităţilor pentru organizarea şi desfăşurarea practicii se întocmeşte anual, la începutul anului universitar;
   * erioada de desfăşurare a stagiului este parte componentă a anului universitar.
   * Stagiul de practică ca componentă a planului de învăţământ este obligatoriu şi constituie condiţia de promovare la următorul an de studiu.
   * Analiza şi validarea locurilor de practică selectate de studenţi se realizează de către conducătorul practicii din partea departamentului.
   * Preliminar deplasării la practică, studenţii sunt convocaţi într-o şedinţă de instructaj referitor la desfăşurarea stagiului de practică,  respectarea securităţii.
   * De asemenea studenților li se înmânează contractul şi caietul stagiului de practică,  sarcini individuale.

'FREE RIDERS' are students who, being part of a team, profit from the input and energy of their fellow students without making an equal contribution themselves in return.
   1. All team members must attend the internship as scheduled. Attendance will be monitored and recorded by the company supervisor.
   2. Each member is required to sign an attendance sheet daily, which will be reviewed weekly by the team leader and company supervisor. The weekly attendance sheet will be uploaded on ELSE together with weekly progress report.
   3. Any absences must be pre-approved by the company supervisor. Documentation will be required.
   4. Only team members who have met their responsibilities, have actively contributed to the project and the final report are eligible to sign the cover page. Contribution is defined as meaningful involvement in research, task completion, report writing and daily attendance.
   5.  Any disputes regarding contributions will be resolved through a meeting with the company supervisor, university mentor and all involved members. Final decisions will be documented.

Consequences for free riding:
   1. Initial warning: Any member identified as not contributing adequately will receive a formal warning from the team leader and all involved members.
   2. Corrective action plan: A corrective action plan will be developed with specific goals and deadlines for the underperforming member.
   3. Continued non-compliance: If the member continues to underperform, a meeting will be held with the company supervisor, university mentor to discuss further actions, which may include removal from the team or failing the internship.

[DOCUMENTATION REQUIRED:](https://else.fcim.utm.md/course/section.php?id=13628)

1. Internship logbook (caiet de pract[că)
2. Internship agreement (contract de practică)
[3. Weekly Attendance Sheet](https://else.fcim.utm.md/mod/resource/view.php?id=68903) (fișă de prezență)
4. Weekly individual activity report
5. Internship group report
6. [Project presentation (PPT)](https://else.fcim.utm.md/mod/assign/view.php?id=60274)

Important note: At the end of the internship, the team leader (or one designated student per team) is responsible for submitting in hard copy to the Internship Coordinator:
      1. Group Report
      2. Internship Agreements of all team members,
      3. Internship logbooks (Caiete de practică) of all team members 
      4. No individual submissions will be accepted. All documents must be delivered together, as a complete team package! 
      5. If any of these elements are missing, the student's grade will be downgraded by the University Internship Coordinator in line with the internship grading policy.

Internship Report and MVP Presentation
1.     Internship Report: Describe the company context, project idea, domain analysis, technologies used, team roles, work completed during September, identified security risks, implemented security measures, challenges encountered, and planned next steps.
2.     MVP Presentation: Present the problem, proposed solution, system architecture, main functionality, security considerations, implemented features, and a short demonstration of the current MVP.
The report and presentation should reflect the work completed during September and also show the planned development for the period from October to December.

Work from October to December
After the internship, students should continue developing and improving the application until December. During this period, teams should add functionality, test the application, and gradually implement and improve additional security measures.

         * [3. Weekly attendance sheet File](https://else.fcim.utm.md/mod/resource/view.php?id=68904)
            1. The Team Leader/or any delegated member presents the Attendance sheet to the company mentor weekly.
            2. The mentor records the hours completed each day, indicates online/offline activity, or marks Absent, where applicable, and validates the sheet with their signature and company stamp.
            3. Each week, the Team Leader must upload a scanned copy of the completed and validated sheet to the designated folder: [Weekly Attendance Sheet](https://utm-my.sharepoint.com/:f:/g/personal/elena_gogoi_faf_utm_md/IgAqWfpgCRF7QIh11fNE7NJUAbZ1BqUJr7HyYqXXO-JIROg?e=4haHg4)
            4. At the end of the internship, the Team Leader must submit all original Attendance Sheets.
         * [4. Weekly Activity Sheet File](https://else.fcim.utm.md/mod/resource/view.php?id=68927)
1.      Complete the weekly sheet with a clear and concise record of your internship activities:
            * List the tasks and activities completed each day, providing specific details where relevant.
            * Briefly summarize the main activities and highlights of the week.
            * Describe the main individual and group tasks completed.
            * Highlight any significant achievements or milestones reached.
            * Mention your specific contribution to the team or project.
            * Record any training sessions, workshops, or other learning activities attended.
2.      Submission procedure
            * Download the weekly activity sheet.
            * Complete the sheet with all individual and group activities carried out during the week.
            * Upload the completed sheet at the end of each week, using the sheet corresponding to that week.
            * Submit one sheet per week. By the end of the 4-week internship, 4 completed sheets must be uploaded.
            * The completed sheets will form part of your Internship Logbook.
            * At the end of the internship, print all 4 completed sheets and attach them to your Internship Logbook.
3.      Evaluation criteria
The weekly activity sheets will be evaluated based on:
            * Organization: Clear structure, headings, and logical sequencing of information.
            * Completeness and accuracy: Relevant activities are recorded accurately and with sufficient detail.
            * Technical content: Technical information is accurate and demonstrates a good understanding of the tasks performed.
            * Individual contribution: The student's specific contribution to the team/project is clearly identified.
            * Timeliness: The sheet is completed and uploaded by the specified deadline.

The template provided below contains all required elements and formatting rules that must be followed. Failure to adhere to the mandatory template and formatting requirements will result in penalties (see the evaluation rubric below).

[Internship report (hard & soft copies)Assignment](https://else.fcim.utm.md/mod/assign/view.php?id=49326)
1. The hard copy of the Group Internship Report must be submitted to the Internship Coordinator and PBL mentors on the first day of the PBL course (Week 5, immediately after the completion of the internship).
2. The soft copy must be uploaded by that date; submission of the digital version is mandatory.

[1. Internship logebook (caiet de practica)](https://else.fcim.utm.md/course/section.php?id=16317)
               1. Each student will complete the Internship Notebook (Caiet de practică).
               2. The notebook must be completed individually by every student throughout the internship.
               3. At the end of the internship, the notebook must bprinted out and submitted together with all other required documents to the Internship Coordinator.
               4. The notebook contains evaluation pages where the company mentor is required to assess the intern on specific dimensions.
               5. At the [final evaluation](https://else.fcim.utm.md/mod/url/view.php?id=64884), the company mentor must validate the general grade by providing: the grade in numbers and letters (mandatory), signature, full name, company stamp, 
If any of these elements are missing, the student's grade will be downgraded by the University Internship Coordinator.

[Project presentation (PPT)](https://else.fcim.utm.md/course/section.php?id=13632)
Students will make a presentation to their university PBL mentors, where they will also report on the progress achieved during their company internship. This presentation will help mentors understand how to proceed with the second report for the PBL course. Each team member will upload their presentation, based on the internship project, during the first week after completing the 4-week internship (28 September – 02 October).

Midterm 1
The grade for Midterm 1 represents the average score awarded by the internship company mentor, based on the student's performance during the first weeks of the internship.
This grade must be:
               * recorded in the internship journal (Caiet de practică),
               * written in both numerical (integer) and letter format,
               * validated with the company's official stamp and the mentor's signature.
If these requirements are not met, the TUM internship supervisor will penalize and downgrade the student. 
The evaluation and validation must be completed by the end of September.
 
Midterm 2
The grade for Midterm 2 is determined by TUM internship supervisors in collaboration with PBL mentor/s, during the fifth week of studies, which coincides with the first PBL class.
This evaluation is based on:
               1. a group presentation, where students present their progress and outcomes from the first four weeks of the internship;
               2. a printed group report (one hard copy per team), summarizing their internship experience and deliverables to date.
The purpose of this midterm checkpoint is to allow mentors to gain insight into each group's progress and provide guidance for the next 11 weeks to support the continuation, improvement, and finalization of the internship project.
 
[Final evaluation](https://else.fcim.utm.md/mod/url/view.php?id=64884)
The [final evaluation](https://else.fcim.utm.md/mod/url/view.php?id=64884) grade is assigned by TUM internship supervisors at the end of the semester, during the winter examination session, in accordance with the schedule published by the Dean's Office.
Attendance at the final exam is mandatory.
The final grade will be based on the following components:
               1. Weekly activity sheets uploaded on ELSE on time – 50%
               2. Peer evaluation – 30%
               3. Self-reflection report – 20%
