**FACULTATEA CALCULATOARE, INFORMATICĂ ȘI MICROELECTRONICĂ**

**DEPARTAMENTUL INGINERIA SOFTWARE ȘI AUTOMATICĂ**

| **APROBAT** **la şedinţa Departamentului ISA nr.**** ___**** din ****_________________** **Șef departament ** **FIODOROV Ion** **conf. univ., dr.** **__________________________** |  | **APROBAT** **la şedinţa Consiliului Facultăţii CIM** **nr.**** ___**** din ****_________________** **Președintele Consiliului CIM** **CIORBĂ Dumitru, ** **conf. univ., dr.** **_______________________** |
| --- | --- | --- |

| **Program de studii:** | *0613.3  Ingineria Software* |
| --- | --- |
| **Cod, Denumirea modulului:** | *S.O.010  Practica în producție* |
| **Beneficiari:** | *Studenții anului III, învățământ cu frecvență * |
| **Ciclul de învățământ:** | *Studii superioare de licență, ciclul I* |
| **Numărul de credite ECTS:** | *8* |

					

					

					

					

					

					**Titularii disciplinei**

					

| **__________________________**      *Nume, prenume,  semnătura titularului* |
| --- |

					

					

					

					

- **PRELIMINARII**

Cursul de practică tehnologică pentru studenții de la Facultatea Calculatoare, Informatică și Microelectronică, programul de studii Securitate informațională, are ca scop să ofere oportunități practice de aplicare și dezvoltare a cunoștințelor tehnologice dobândite în cadrul programului de studii. 

Cursul reprezintă o componentă esențială în formarea competențelor tehnologice și profesionale ale studenților la anul III, pregătindu-i pentru cerințele și provocările industriei IT.

În cadrul programului de practică tehnologică, studentul va avea oportunitatea de a se familiariza cu mediul de lucru real și de a aplica cunoștințele teoretice acumulate în timpul studiilor într-un context practic. 

**Obiectivul general**

Dezvoltarea cunoștințelor și abilităților practice în domeniul tehnologiei informației prin participarea activă la un stagiu de practică tehnologică**.**

**Obiectivele specifice:**

•	Învațarea folosirii limbajelor de programare specifice sau tehnologii pentru a dezvolta aplicații sau soluții tehnologice funcționale.

•	Colaborarea cu echipa de dezvoltare pentru contribuirea la proiecte existente sau pentru a dezvolta noi proiecte în conformitate cu cerințele specificate.

•	Documentarea procesului de dezvoltare, inclusiv specificații tehnice, diagrame și manuale pentru utilizatori.

•	Înțelegerea și respectarea standardelor de calitate și regulilor de securitate aplicabile în domeniul de specializare.

•	Dezvoltarea abilităților de comunicare eficientă și colaborarea cu colegii, supervizorii și clienții pentru a atinge obiectivele proiectelor.

•	Identificarea și soluționarea problemelor tehnice care pot apărea în timpul procesului de dezvoltare sau implementare a soluțiilor tehnologice.

- Înțelegerea și aplicarea conceptelor pentru a îmbunătăți performanța și eficiența proiectelor

**Condiţii de desfăşurare a procesului educaţional pentru locul de practică**

Stagiul de practică tehnologică poate fi desfășurat atât la o întreprindere din domeniul de specialitate, cât și în cadrul departamentului de profil, cu scopul de a atinge obiectivele stabilite. Studentul care efectuează practica beneficiază de îndrumare din partea unui cadru didactic care este responsabilul de practică din partea departamentului.

Pentru a efectua practica la o companie din domeniul de specialitate, este necesară designarea unui coordonator din partea unității economice gazdă, asigurarea unui PC/laptop și a accesului la internet.

Analiza și validarea locurilor de practică alese de către studenți sunt efectuate de către departamentul de profil, care este responsabil de organizarea practicii.

Înainte de începerea practicii, studentul trebuie să prezinte informații referitoare la locul de desfășurare a practicii sub forma unui contract de practică sau a unui certificat care atestă angajarea sa în cadrul companiei unde va petrece perioada de practică. Aceste documente trebuie depuse cu cel puțin 15 zile înainte de începerea practicii. După această etapă, se întocmește un ordin de practică care va fi semnat de prorectorul responsabil cu instruirea practică.

Caietul de practică se repartizează de coordonator și reprezintă un jurnal în care studentul va înregistra activitățile desfășurate, obiectivele atinse, provocările întâmpinate și observațiile personale în timpul practicii. Acest caiet va servi ca mijloc de evidență și autoevaluare, contribuind la urmărirea progresului și a învățămintelor dobândite în timpul stagiului de practică.

**Condiţii de desfăşurare a procesului educaţional pentru caietul de practică**

Caietul de practică cuprinde următoarele elemente:

- Caietul de sarcini: unde sunt enumerate tematicile lucrărilor preconizate pentru practica tehnologică, iar termenele planificate pentru realizarea acestora sunt notate cu indicarea datelor de început și sfârșit, precum și durata estimată în număr de zile. Se realizează o planificare detaliată, includând tematicile pentru fiecare săptămână.

- Sarcina individuală: conține tema exactă repartizată pentru stagiul de practică, oferind un conținut concis al sarcinilor individuale și mențiuni cu privire la realizarea acestora.

- Fișe de activitate pentru fiecare săptămână: unde se înregistrează detaliat sarcinile planificate, activitățile efectuate și observațiile personale înregistrate pe parcursul fiecărei săptămâni de practică. Aceste fișe asigură evidența clară și ordonată a progresului și experienței acumulate pe tot parcursul practicii tehnologice.

Înainte de a pleca în stagiul de practică, studentul are responsabilitatea de a completa caietul de sarcini și sarcina individuală. 

După completare trebuie să obțină aprobarea și semnătura din partea coordonatorului de practică de la departament. Această semnătură confirmă că tematica și sarcinile stabilite sunt adecvate și conforme cu obiectivele și cerințele practicii tehnologice, asigurându-se astfel de acordul coordonatorului privind direcția și scopul activităților ce urmează a fi desfășurate în cadrul stagiului de practică.

**Condiţii de desfăşurare a procesului educaţional pentru raportul de practică**

Raportul de practică reprezintă un document esențial în cadrul experienței de practică tehnologică a studentului. Acesta constituie o sinteză detaliată și reflectivă a activităților, rezultatelor și învățămintelor dobândite pe parcursul stagiului de practică în mediul real al unei întreprinderi sau organizații.

Scopul raportului de practică este de a oferi o prezentare coerentă și structurată a tuturor aspectelor relevante ale practicii, evidențiind contribuția și implicarea personală a studentului în rezolvarea problemelor și în realizarea activităților specifice domeniului de studiu. Raportul nu doar documentează activitățile desfășurate, ci și pune accent pe analiză și evaluare, oferind o perspectivă critică și reflexivă asupra experienței practice și a rezultatelor obținute.

Prin intermediul acestui raport, studentul va avea oportunitatea de a comunica succint și precis aspectele cheie ale practicii, inclusiv descrierea tematicii abordate, metodologiile utilizate, provocările întâmpinate și soluțiile adoptate. De asemenea, se va evidenția contribuția personală și relevanța experienței de practică în contextul formării profesionale.

Cerințele față de raportul de practică sunt clare și riguroase, având scopul de a asigura o documentare și prezentare corespunzătoare a experienței de practică a studentului. Raportul trebuie elaborat în conformitate cu structura și cerințele specifice memoriului explicativ, pentru a asigura coerenta și relevanța conținutului.

Raportul de practică trebuie să respecte următoarele cerințe:

- Tematica practicii: să coincidă cu tema aprobată de către responsabilul de practică de la departament și să fie scrisă în caietul de practică și pe foaia de titlu a raportului.

- Structura raportului: raportul trebuie să urmeze structura specifică unui raport de practică, inclusiv pagină de titlu și cuprins, asigurând astfel o organizare clară și accesibilă a conținutului.

- Semnătura conducătorului de practică: raportul trebuie să fie semnat de către conducătorul de practică de la întreprindere, atestând astfel verificarea și aprobarea lucrării pentru susținere. 

- Redactare conform standardelor: lucrarea trebuie redactată în concordanță cu standardele specifice pentru a asigura o prezentare profesionistă și coerentă a conținutului.

Limba de prezentare a raportului va corespunde limbii de studiu la programul respectiv, respectând standardul specific de redactare și exprimare.

Raportul de practică trebuie să conțină atașat contractul de practică și să fie tipărit pe foi de format A4, iar apoi copertat simplu, pentru o prezentare corespunzătoare și ușoară de consultat.

- **PRECONDIŢII DE ACCES LA DISCIPLINĂ/MODUL**

| **Conform planului de învăţământ** | Dacă studentul a încheiat cu succes sesiunea și a fost promovat în anul III al programului și, în plus, are deja stabilit locul de practică și tema pentru practică, atunci, în general, ar trebui să fie pregătit să înceapă stagiul de practică. |
| --- | --- |
| **Conform competenţelor** | Un student care se pregătește pentru practică ar trebui să aibă următoarele competențe sau calități: Studentul ar trebui să aibă o bază solidă de cunoștințe academice în domeniul de studiu Abilitatea de a comunica eficient, atât în scris, cât și oral, este importantă pentru a interacționa cu colegii și supervizorii în timpul practicii. Capacitatea de a lucra în echipă și de a colabora cu colegii și supervizorii este crucială, deoarece majoritatea proiectelor de practică implică colaborare. Competențele tehnice, studentul ar trebui să aibă cunoștințe și abilități relevante pentru a desfășura sarcinile necesare în timpul practicii. Abilitatea de a identifica și rezolva probleme tehnice sau de altă natură care pot apărea pe parcursul practicii. Capacitatea de a analiza informații, de a evalua situații și de a lua decizii în mod logic și rațional. Abilitatea de a planifica, organiza și gestiona proiectele, inclusiv respectarea termenelor și obiectivelor stabilite. Atenția la detalii este importantă pentru a evita erorile și pentru a asigura calitatea muncii desfășurate în timpul practicii. Respectarea standardelor etice și a regulilor organizației este esențială în timpul practicii. |

- **COMPETENŢELE CARE URMEAZĂ A FI DEZVOLTATE**

Unitatea de curs prevede formarea următoarelor competente profesionale.

**CP1.** **Elaborarea și proiectarea arhitecturii**

***Cunoștințe:***

- Modele de arhitectura, metodologii și instrumente de proiectare a sistemelor.

			- Cerințele arhitecturii sistemelor: performanță, mentenabilitate, extensibilitate, scalabilitate, disponibilitate, securitate și accesibilitate.

- Costurile, beneficiile și riscurile unei arhitecturi a sistemului.

- Arhitectura întreprinderii și standardele interne ale companiei.

- Noi tehnologii emergente (de exemplu, sisteme distribuite, modele de virtualizare, seturi de date, sisteme mobile)

***Abilități:***

- Oferă expertiză pentru a ajuta la rezolvarea problemelor tehnice complexe și pentru a asigura implementarea celor mai bune soluții de arhitectură.

- Utilizează cunoștințele sale tehnologice din diferite domenii pentru a elabora şi implementa arhitectura întreprinderii.

- Înțelege obiectivele companiei care au impact asupra componentelor arhitecturii.

- Ajută la comunicarea arhitecturii întreprinderii și a standardelor, principiilor și obiectivelor către diferite echipe implicate; dezvoltă modele de design și modele pentru a ajuta analiștii sistemului în proiectarea unor aplicații coerente.

***Standarde minime  de performanță pentru evaluarea competențelor***: exploatează cunoștințele de specialitate pentru a defini adecvat tehnologia și specificațiile relevante necesare pentru elaborarea mai multor proiecte TIC, a aplicațiilor sau a îmbunătățirii infrastructurii.

**CP2. Proiectarea și dezvoltarea aplicațiilor**

***Cunoștințe:***

- Programe/module software adecvate.

- Componente hardware, instrumente și arhitecturi.

- Proiectare funcțională.

- Tehnologii de ultimă oră.

- Limbaje de programare.

- Baze de date (DBMS).

- Sisteme de operare și platforme software.

- Mediu de dezvoltare integrat (IDE - integrated development environment).

- Dezvoltarea rapidă a aplicațiilor (metoda RAD).

- Problemele legate de drepturile de proprietate intelectuală (IPR).

- Tehnologia de modelare tehnică și limbi/limbaje.

- Limbile de definire a interfeței (IDL).

- Probleme de securitate.

***Abilități:***

- Explică și comunică clientului informații privind designul//dezvoltarea aplicației.

- Efectuează și evaluează rezultatele testelor în funcție de specificațiile produsului.

- Aplică arhitecturi software și/sau hardware adecvate.

- Dezvoltă interfețe de utilizator, componente business software și componente software integrate.

- Gestionează și garantează nivel ridicat de calitate şi de coeziune.

- Utilizează modele de date.

- Efectuează și evaluează rezultatele testului în mediul client sau mediul țintă.

- Colaborează cu echipa de dezvoltare și cu designerii de aplicații.

***Standarde minime  de performanță pentru evaluarea competențelor***:

- Acționează creativ pentru a dezvolta aplicații și a selecta opțiunile tehnice adecvate.

- Participă la alte activități de dezvoltare.

- Optimizează dezvoltarea, întreținerea și performanța aplicațiilor prin utilizarea modelelor de design și prin reutilizarea soluțiilor testate.

**CP3. Integrarea componentelor**	

***Cunoștințe:***

- Componente/module hardware/software, indiferent dacă sunt vechi, existente sau noi.

- Impactul integrării unui sistem nou asupra organizației sau a sistemului existent.

- Tehnici de interfaţare între module, sisteme și componente.

- Tehnici de testare a integrării.

- Instrumentele de dezvoltare (ex., mediul de dezvoltare, gestionarea, controlul modificărilor și accesul la codul sursă).

- Bune practici de design.

***Abilități:***

- Măsoară performanța sistemului înainte, în timpul și după integrarea sistemului.

- Identifică și înregistrează activitățile, problemele și măsurile corective legate de întreținere.

- Adaptează nevoile clienților la produsele existente.

- Verifică dacă capacitățile și eficiența sistemelor integrate corespund specificațiilor.

- Securizează și face backup-ul datelor pentru a asigura integritatea lor în timpul integrării datelor sau a sistemului.

***Standarde minime  de performanță pentru evaluarea competențelor***:

- Ia în considerare propriile acțiuni și cele ale terților în procesul de integrare.

- Respectă standardele și procedurile de control adecvate pentru a menține integritatea funcționalității și fiabilitatea generală a sistemului.

**CP4. Testarea aplicațiilor**	

***Cunoștințe:***

- Tehnicile, infrastructura și instrumentele necesare utilizate în procesul de testare.

- Ciclul de viață al unui proces de testare.

- Tipurile de teste (funcțional, de integrare, performanță, gradul de utilizare, sarcină etc.).

- Standardele naționale și internaționale care definesc criteriile de calitate pentru testare.

- Specificul tehnologiilor legate de web, cloud, instrumente mobile și de probleme de mediu.

***Abilități:***

- Creează și gestionează o activitate de testare.

- Gestionează și evaluează procesul de testare.

- Proiectează teste de sistem informatic.

- Pregătește și efectuează teste ale sistemelor informatice.

- Înregistrează și documentează testele și rezultatele acestora.

***Standarde minime  de performanță pentru evaluarea competențelor***:

- Asigură expertiza pentru a suprave ghea programele complexe de testare. 

- Asigură documentarea testelor și a rezul tatelor pentru a furniza informații managerilor relevanți ai procese lor cum ar fi proiec tanții, utilizatorii sau tehnicienii de întreținere. 

- Asigură conformitatea cu procedurile de testare, inclusiv trasabilitatea documentată.

**CP5. Implementarea soluțiilor**	

***Cunoștințe:***

- Tehnici de analiză a performanței.

- Tehnicile legate de gestionarea problemelor (funcționare, performanță, compatibilitate).

- Software-ul de ambalare/packaging și metode și tehnici de distribuție/desfăşurare.

- Impactul implementării/desfăşurării asupra arhitecturii existente.

- Tehnologiile și standardele care se utilizeză în timpul implementării/desfăşurării.

***Abilități:***

- Organizează procesul de implementare și activită țile de lansare a produselor.

- Organizează și planifică activitățile de beta-test şi de testare a soluției în mediul său operațional final.

- Configurează componentele la orice nivel pentru a garanta interoperabilitatea generală corectă.

- Identifică și angajează expertiza necesară pentru a rezolva problemele de interoperabilitate.

- Organizează și contro lează prestarea de servicii de asistență inițială, inclusiv instruirea utilizatorilor în timpul demarării sistemului.

- Organizează funcționarea bazelor de date și gestionează migrarea datelor.

- Colaborează pentru modificarea codului terță parte. Susține și menține software modificat.

***Standarde minime  de performanță pentru evaluarea competențelor***:

- Ia în considerare propriile acțiuni și cele ale altora pentru a oferi soluții și a iniția o comunicare și o colaborare cu părțile interesate.

- Asigură expertiza pentru a influența, prin consiliere și asistență, dezvoltarea de soluții

**CP6. Elaborarea documentației**	

***Cunoștințe:***

- Instrumente pentru producerea, editarea și distribuirea documentelor profesionale.

- Instrumente pentru crearea  prezentărilor multimedia.

- Diferitele documente tehnice necesare pentru proiectarea, dezvoltarea și implementarea produselor, aplicațiilor și serviciilor.

- Mijloace de gestiune a versiunilor pentru controlul producției de documente.

***Abilități:***

- Respectă și promovează utilizarea eficientă a standardelor corporative pentru publicații.

- Pregătește șabloane pentru publicații commune.

- Organizează și controlează procesele de management al conținutului.

- Menţine coerenţa publicațiilor cu soluția pe parcursul întregului ciclu de viață.

***Standarde minime  de performanță pentru evaluarea competențelor***: adaptează nivelul de detaliere în funcție de obiectivul documentației și publicul vizat.

**CP7. Ingineria sistemelor**	

***Cunoștințe:***

- Programe/module adecvate, SGBD și limbaje de programare adecvate.

- Componente hardware, instrumente și arhitecturi hardware.

- Proiectare funcțională și tehnică.

- Tehnologiile de ultimă oră.

- Limbi de programare.

- Bazele securităţii informaţiei.

***Abilități:***

- Explică și comunică clientului informații privind proiectarea/ dezvoltarea.

- Lansează și evaluează rezultatele testelor în funcție de specificațiile produsului.

- Aplică arhitecturi software și/sau hardware adecvate.

- Proiectează și dezvoltă arhitectura hardware, interfețele utilizatorilor, componentele business software și componentele software integrate.

- Gestionează și garantează niveluri înalte de coeziune și calitate în dezvoltarea de software complexe.

- Utilizează modele de date.

- Aplică modele adecvate de dezvoltare și/sau proce se, pentru a se dezvolta eficient și productiv.

***Standarde minime  de performanță pentru evaluarea competențelor***:

- Valorifică cunoștințe le de specialitate și înțelegerea aprofun dată a infrastructurii TIC și a procesului de gestionare a problemelor pentru identificarea defecțiunilor și rezolvarea acestora cu cele mai mici întreruperi posibile.

- Ia decizii informa te în situații tensio nate emoțional cu privire la acțiunile adecvate necesare pentru a minimiza impactul asupra afacerii. 

- Identifică rapid componente le defecte, selectea ză alternative privind modul de reparare, înlocuire sau reconfigurare.

**CP8. Managementul problemelor**

***Cunoștințe:***

- Infrastructura IT globală a organizațiilor și componentele cheie ale acestora.

- Procedurile pentru raportarea informațiilor din partea organizațiilor.

- Procedurile pentru raportarea situațiilor critice ale organizațiilor.

- Domeniul de aplicare și disponibilitatea instrumentelor de diagnosticare.

- Legătura dintre elementele de infrastructură a sistemului și impactul eșecurilor asupra proceselor relevante pentru afaceri.

***Abilități:***

- Controlează evoluția problemelor pe tot parcursul ciclului de viață și asigură o comunicare eficientă.

- Identifică potențialele defecțiuni ale componentelor critice și acționează pentru a limita efectul defecțiunilor.

- Conduce auditurile de gestionare a riscurilor și acționează pentru a reduce impactul acestora.

- Alocă resurse adecvate activităților de întreținere, luând în considerare costurile și riscurile.

- Comunică la toate nivelurile pentru a asigura implementarea resurselor interne și externe adecvate pentru a minimiza întreruperile.

***Standarde minime  de performanță pentru evaluarea competențelor***:

- Folosește cunoștin țele de specialitate și înțelegerea aprofund ată a infrastructurii TIC și a procesu lui de gestionare a problemelor pentru identificarea defecți unilor și rezolvarea acestora cu cele mai mici întreru peri posibile.

-  Ia decizii informate în situații  tensionate emoțio nal cu privire la acțiunile  adecvate pentru a minimi za impactul asupra afacerii. 

- Identifică rapid componentele defecte, selectează alternative privind modul de reparare, înlocuire, reconfigurare.

	

**CP9. Îmbunătățirea proceselor**

***Cunoștințe:***

- Metode de cercetare, comparare și metode de măsurare

- Metode de evaluare, proiectare și implementare.

- Procesele interne existente

- Dezvoltarile/evoluțiile relevante în domeniul TIC (de exemplu, virtualizarea, datele deschise etc.) și impactul lor potențial asupra proceselor

- Specificitatea tehnologi lor web, cloud și mobile.

- Optimizarea resurselor folosite și reducerea deșeurilor

***Abilități:***

- Redacteaza, documentează și catalogeaza procesele și procedurile esențiale.

- Propune modificări ale procesului pentru a facilita și raționaliza îmbunătățirile.

***Standarde minime  de performanță pentru evaluarea competențelor***:

- Valorifică cunoștințelor de specialitate pentru a studia procesele și soluțiile existente în domeniul TIC pentru a defini posibilele inovații.

- Face recomandări bazate pe argumente științifice.

Următoarele competențe transversale:

- **Autonomie şi responsabilitate- **demonstrează executarea responsabilă a sarcinilor profesionale în condiţii de autonomie.	

- **Interacţiune socială - **execută rolurile şi activităţile specifice muncii în echipă şi distribuie sarcinile între membri pe niveluri subordonate.	

- **Dezvoltare personală şi profesională -** conştientizează nevoia de formare continuă cu utilizarea eficientă a resurselor şi tehnicilor de învăţare pentru dezvoltarea personală şi profesională.

- **ADMINISTRAREA DISCIPLINEI/MODULULUI**

| **Cod** | **Anul ** | **Semestrul** | **Numărul de ore** | **Credite** |
| --- | --- | --- | --- | --- |
|  |  |  | **Curs** | **Seminar** | **Lucrări de laborator** | **Lucrări practice** | **Proiectare** | **Lucrul individual** |  |
| **S.O.010** | **Învăţământ cu frecvenţă** |
|  | III | 5 |  |  |  |  |  | 240 | 8 |

- **REZULTATELE ÎNVĂŢĂRII, CONŢINUTURI ŞI METODE DIDACTICE APLICATE**

| **Rezultatele învăţării.** **Studentul trebuie:** | **Activități** | **Metode de predare** | **Realizarea în timp (ore)** |
| --- | --- | --- | --- |
|  |  |  | **învăţământ cu frecvenţă** |
|  |  |  | **lucrul individual** |
| **1** | **2** | **4** | **5** |
| Studentul trebuie să cunoască cultura organizațională și să înțeleagă dinamica echipei și a proiectelor. Trebuie să dezvolte abilități de comunicare și networking într-un mediu profesional. | Introducere în organizație, cunoașterea echipei și a proiectelor în curs. | Introducere formală în organizație, prezentări individuale și întâlniri cu membrii echipei, discuții orientate pe proiecte. | **4** |
| Studentul trebuie să dobândească cunoștințe avansate în limbajul de programare/tehnologie specific. Trebuie să devină familiar cu codul sursă existent și cu resursele tehnologice utilizate în organizație. | Studiu inițial al proiectelor, aprofundarea în limbajul de programare/tehnologie, familiarizare cu codul sursă și resursele existente. | Cursuri teoretice, sesiuni practice de programare, studiu independent al documentației și codului sursă. | **12** |
| Studentul trebuie să dezvolte abilități de documentare și organizare. Trebuie să învețe să mențină un jurnal precis al activităților și progresului zilnic. | Începerea înregistrărilor zilnice în caietul stagiului de practică. | Instrucțiuni detaliate privind modul de documentare, exemple de înregistrări, feedback regulat. | **4** |
| Studentul trebuie să dobândească abilități practice în dezvoltarea software și să înțeleagă procesul de lucru într-o echipă de dezvoltare. Trebuie să poată implementa funcționalități specifice și să rezolve probleme tehnice. | Participare la dezvoltarea aplicației sub supravegherea unui mentor, contribuind la funcționalitățile stabilite. | Dezvoltare bazată pe proiect, sesiuni de code review, mentorat individual. | **40** |
| Studentul trebuie să devină autonom în rezolvarea sarcinilor, să dobândească abilități avansate în depurare și testare. Trebuie să învețe să lucreze eficient în echipă și să își îmbunătățească produsul prin feedback și colaborare. | Lucrul independent și colaborarea cu echipa de dezvoltare pentru a finaliza funcționalități, depurare și testare. | Proiecte individuale și de grup, sesiuni de laborator, teste practice. | **80** |
| Studentul trebuie să dezvolte abilități de redactare tehnică și să învețe să explice concepte tehnice într-un limbaj accesibil. Trebuie să înțeleagă importanța documentației în dezvoltarea software. | Documentarea detaliată a aplicației, scrierea specificațiilor tehnice și a manualelor pentru utilizatori. | Exemple de documentație, sesiuni de brainstorming, ghidare individuală. | **20** |
| Studentul trebuie să dezvolte abilități de raportare și comunicare scrisă. Trebuie să fie capabil să evalueze progresul proiectului, să identifice și să descrie dificultățile întâmpinate și să propună soluții. | Pregătirea primului raport intermediar pentru supervizorul de practică, inclusiv descrierea progresului și dificultăților întâmpinate | Instrucțiuni privind structura și conținutul raportului, ghidare în redactare, discuții regulate cu supervizorul. | **20** |
| Studentul trebuie să obțină competențe avansate în dezvoltarea și testarea software, inclusiv asigurarea calității produsului. Trebuie să învețe procesele de lansare și să fie capabil să gestioneze proiectele tehnologice cu încredere. | Finalizarea dezvoltării aplicației, testarea finală și pregătirea pentru lansare. | Instrucțiuni pentru etapele finale ale dezvoltării, testare, discuții de grup, analiză post-implementare. | **20** |
| Studentul trebuie să dezvolte abilități avansate de sintetizare și redactare. Trebuie să fie capabil să reflecteze asupra experienței de practică, să evidențieze realizările și să identifice lecțiile învățate. | Scrierea raportului final pentru evaluarea stagiului, inclusiv reflectarea asupra experienței, realizări și lecții învățate. | Ghidare în structura și conținutul raportului final, sesiuni de brainstorming, feedback asupra draft-urilor. | **20** |
| Studentul trebuie să dobândească abilități de prezentare și comunicare orală. Trebuie să fie capabil să argumenteze și să susțină proiectul în fața unui public și să primească feedback constructiv. | Prezentarea proiectului și raportului final supervizorului pentru evaluare și feedback. | Instrucțiuni pentru prezentare, sesiuni de antrenament în prezentare, discuții cu supervizorul. | **10** |
| Studentul trebuie să dezvolte abilități de autoevaluare și autocorectare. Trebuie să înțeleagă importanța documentării și a reflectării asupra propriei evoluții în timpul practicii. | Finalizarea înregistrărilor zilnice, evaluare personală și pregătirea pentru încheierea practicii. | Ghidare în finalizarea documentației, autoevaluare, discuții privind experiența practicii. | **10** |

			- **SUGESTII PENTRU ACTIVITATEA INDIVIDUALĂ A STUDENŢILOR**

| **Nr. crt.** | **Conținut activitate individuală** | **Durata, ore** | **Forma de control** | **Termeni de control (perioada)** |
| --- | --- | --- | --- | --- |
| **1** | Introducere în organizație, cunoașterea echipei și a proiectelor în curs. | **4** | Evaluare continuă de către supervizorul de practică și feedback regulat. | Controlul va avea loc pe parcursul primei săptămâni de practică și va continua pe parcursul stagiului, cu sesiuni de evaluare săptămânale. |
| **2** | Studiu inițial al proiectelor, aprofundarea în limbajul de programare/tehnologie, familiarizare cu codul sursă și resursele existente. | **12** | Evaluare a cunoștințelor tehnice și a înțelegerii conceptelor prin teste practice și sesiuni de code review. | Controlul inițial se va desfășura în primele două săptămâni de practică, urmat de evaluări periodice în funcție de progresul învățării. |
| **3** | Începerea înregistrărilor zilnice în caietul stagiului de practică. | **4** | Verificarea documentelor zilnice de către supervizorul de practică. | Control zilnic, cu feedback imediat pentru a asigura acuratețea și consistența în documentare |
| **4** | Participare la dezvoltarea aplicației sub supravegherea unui mentor, contribuind la funcționalitățile stabilite. | **40** | Evaluare continuă a contribuțiilor la proiect, precum și sesiuni de code review regulate. | Control continuu pe parcursul stagiului, cu feedback săptămânal pentru a monitoriza progresul. |
| **5** | Lucrul independent și colaborarea cu echipa de dezvoltare pentru a finaliza funcționalități, depurare și testare. | **80** | Control prin intermediul supervizorului de practică și prin testarea funcționalităților dezvoltate. | Control continuu și teste de calitate în timp real pe măsură ce funcționalitățile sunt finalizate. |
| **6** | Documentarea detaliată a aplicației, scrierea specificațiilor tehnice și a manualelor pentru utilizatori. | **20** | Verificare și validare a documentației de către supervizorul de practică. | Control continuu pe parcursul procesului de documentare, cu sesiuni de revizuire planificate. |
| **7** | Pregătirea primului raport intermediar pentru supervizorul de practică, inclusiv descrierea progresului și dificultăților întâmpinate | **20** | Evaluare a conținutului și a calității raportului intermediar de către supervizor. | Control înainte de prezentarea raportului intermediar, cu posibilitatea de a face corecții și îmbunătățiri. |
| **8** | Finalizarea dezvoltării aplicației, testarea finală și pregătirea pentru lansare. | **20** | Testarea funcțională a aplicației și revizuirea de către echipa de dezvoltare, inclusiv sesiuni de testare și verificare a calității. | Control în timp real pe măsură ce dezvoltarea progresează, cu o evaluare detaliată înainte de lansare. |
| **9** | Scrierea raportului final pentru evaluarea stagiului, inclusiv reflectarea asupra experienței, realizări și lecții învățate. | **20** | Evaluarea conținutului și a structurii raportului final de către supervizorul de practică și de către comisia de evaluare. | Control înainte de data limită pentru predarea raportului final, cu feedback și corecții, dacă este necesar. |
| **10** | Prezentarea proiectului și raportului final supervizorului pentru evaluare și feedback. | **10** | Evaluarea prezentării și a abilităților de comunicare în cadrul prezentării finale, urmată de sesiuni de întrebări și răspunsuri cu supervizorul. | Control în timpul prezentării finale, cu discuții ulterioare pentru feedback și evaluare. |
| **11** | Finalizarea înregistrărilor zilnice, evaluare personală și pregătirea pentru încheierea practicii. | **10** | Evaluarea înregistrărilor zilnice de către student și supervizor, autoevaluarea studentului și discuții privind evoluția sa în timpul practicii. | Control continuu pe parcursul stagiului, cu o evaluare finală înainte de încheierea practicii. |
| **TOTAL** | **240** |  |  |

		- **EVALUAREA DISCIPLINEI**

| **Periodică** | **Curentă** | **Studiu individual** | **Proiect/teză** | **Examen ** |
| --- | --- | --- | --- | --- |
| **EP 1** | **EP 2** |  |  |  |  |
| **Învăţământ cu frecvenţă ** |
| 15% | 15% | 15% | 15% |  | 40% |
| Standard minim de performanţă Completarea caietului de practică Realizarea raportului de practică conform cerințelor indicate, încărcat pe platforma; Susținerea practicii în termenul stabilit, conform calendarului universitar mimim pe nota ”5”. |

**VIII. CRITERII DE EVALUARE**

| **Activitate** | **Componente evaluare** | **Metodă de evaluare, **   **Criterii de evaluare** | **Pondere în nota finală a activității** | **Ponderea în evaluarea disciplinei** |
| --- | --- | --- | --- | --- |
| **Învăţământ cu frecvenţă ** |
| **Evaluare periodică I** | Reprezintă evaluarea realizată de coordonatorul din companie pe parcursul stagiului de practică, se referă la performanța și progresul studentului în îndeplinirea sarcinilor și responsabilităților specifice domeniului tehnologic în cadrul organizației. Coordonatorul va acorda o notă care reflectă evaluarea sa asupra implicării, competențelor tehnice și abilităților de lucru ale studentului, însoțită de comentarii și sugestii constructive pentru dezvoltarea ulterioară a abilităților tehnologice și profesionale ale studentului. Această notă este înregistrată în caietul de practică. | Coordonatorul ia în considerare următoarele aspecte: Participarea activă și implicarea în proiectele și activitățile desfășurate în organizație. Abilitățile tehnice demonstrate în cadrul proiectelor și sarcinilor atribuite. Capacitatea de a lucra în echipă și de a comunica eficient cu colegii și supervizorii. Rezolvarea problemelor și adaptabilitatea la cerințele specifice ale mediului de lucru. Profesionalismul și etica în cadrul activităților desfășurate. | 100% | **15%** |
| **Evaluare periodică II** | Conținutul raportului de practică. Această evaluare are scopul de a analiza și evalua informațiile prezentate în raportul de practică, reflectând astfel progresul și rezultatele obținute de student în timpul stagiului de practică. | Relevanța conținutului - se evaluează raportul de practică în funcție de relevanța conținutului, adâncimea analizei, coerența și claritatea informațiilor, precum și capacitatea de sinteză a studentului. | 25% | **15%** |
|  |  | Profunditatea analizei - se evaluează nivelul de analiză critică și reflexie al studentului în raportul de practică, evidențiind înțelegerea profundă a domeniului, capacitatea de a identifica și analiza critic provocările și dificultățile întâmpinate, precum și învățămintele și competențele dobândite. | 25% |  |
|  |  | Coerența și claritatea informațiilor - se evaluează coerența și claritatea informațiilor în raportul de practică, analizând structura logică, utilizarea secțiunilor relevante și abilitatea studentului de a comunica ideile și rezultatele obținute într-un mod clar și coerent. | 25% |  |
|  |  | Capacitatea de sinteză - se evaluează capacitatea studentului de a sintetiza și evidenția aspectele cheie ale experienței de practică în raportul său, inclusiv abilitatea de a extrage și prezenta succint concluziile relevante, evidențiind învățămintele și rezultatele principale obținute în timpul stagiului de practică. | 25% |  |
| **Evaluare curentă** | Evaluarea caietului de practică, inclusiv corectitudinea completării și a conținutului. Scopul acestei evaluări este de a verifica și evalua în mod regulat progresul și activitățile desfășurate de către student în timpul practicii tehnologice.   Nota acordată în evaluarea curentă va fi înregistrată în borderoul de evaluare, alături de alte evaluări. Această notă reflectă evaluarea coordonatorului și reprezintă un indicator al performanței și progresului studentului în timpul practicii tehnologice. | Corectitudinea completării caietului de practică în conformitate cu cerințele și structura specificată. Se urmărește dacă sunt incluse informațiile relevante despre activitățile desfășurate, proiectele abordate și rezultatele obținute. | 25% | **15%** |
|  |  | Conținutul caietului de practică ce include descrieri ale sarcinilor și proiectelor, observații și reflecții asupra experiențelor, probleme întâmpinate și soluții găsite, rezultate obținute și învățăminte relevante. | 50% |  |
|  |  | Organizarea și structura caietului de practică, claritatea și coerența înregistrărilor și capacitatea de a evidenția punctele cheie ale experienței de practică. | 25% |  |
| **Studiul individual** | Structurarea și redactarea raportului de practică, în conformitate cu cerințele și standardele prestabilite | Structura raportului - se va verifica dacă raportul are o structură logică și coerentă, cu secțiuni bine definite, cum ar fi introducere, descrierea activităților, rezultate și concluzii. Profesorul va analiza modul în care informațiile sunt organizate și prezentate în raport. | 50% | **15%** |
|  |  | Redactarea - profesorul va evalua calitatea redactării raportului. | 25% |  |
|  |  | Conformitatea cu cerințele și standardele - profesorul va verifica în ce măsură raportul respectă cerințele și standardele prestabilite pentru practica tehnologică. Aceasta poate include respectarea formatului, lungimii, stilului de redactare și standardelor academice sau profesionale relevante | 25% |  |
| **Evaluarea finală** | Prezentarea finală a proiectului de practică în fața comisiei de evaluare. În cadrul acestei prezentări, fiecare student are un timp limitat de aproximativ 5-7 minute pentru a prezenta principalele aspecte și realizări obținute în timpul practicii tehnologice. | Calitatea și claritatea prezentării, conținutul | 30% | **40%** |
|  |  | Relevanța informațiilor prezentate, | 40% |  |
|  |  | Abilitățile de comunicare și de prezentare. | 30% |  |

		**X****. REFERINŢE BIBLIOGRAFICE**

		

		**Obligatorii**

		

- Ghid de organizare și desfășurare a practicii în cadrul UTM, https://utm.md/acte_normative/interne/ghidStagiiPractica.pdf 

- Curs pentru studenții cu frecvență la zi [https://else.fcim.utm.md/course/view.php?id=3220](https://else.fcim.utm.md/course/view.php?id=3220)

Curs pentru studenții cu frecvență redusă https://else.fcim.utm.md/course/view.php?id=3224

**Suplimentare**

- Regulament privind organizarea şi desfășurarea stagiilor de practică a studenților UTM, [https://utm.md/wp-content/uploads/2019/03/Regulament-privind-organizarea-%C5%9Fi-desf%C4%83%C8%99urarea-stagiilor-de-practic%C4%83-a-studen%C8%9Bilor-UTM.pdf](https://utm.md/wp-content/uploads/2019/03/Regulament-privind-organizarea-şi-desfășurarea-stagiilor-de-practică-a-studenților-UTM.pdf)