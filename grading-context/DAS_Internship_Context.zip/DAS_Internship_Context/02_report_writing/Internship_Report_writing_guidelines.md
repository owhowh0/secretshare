|  | **Technical University of Moldova** **Faculty ****o****f Computers, Informatics, ****a****nd Microelectronics** **Department of Software Engineering and Automation** **Software Engineering Study Programme** |
| --- | --- |

**INTERNSHIP REPORT**

**Project title**

**Team No. …**

Team members:

| Student 1: Student 2: Student 3. etc. | Name Surname, group Name Surname, group Name Surname, group | *Signature *Signature *Signature |
| --- | --- | --- |
| Mentor: | Name Surname, title | Signature |

*****By signing the cover page of this report, each student confirms their active involvement in both the development of the project and the writing of the report. Students who did not contribute meaningfully are not permitted to sign.

Submission date: [DD/MM/YYYY]

**Chisinau, 2025**

To ensure a clear, well-structured, and professional final paper, standard formatting rules must be followed. These guidelines help organize the content in line with academic requirements and make the thesis easier to read and evaluate. Proper formatting also reflects precision and responsibility in academic work.

- The report must be written in an impersonal style (the use of first-person pronouns is not permitted).

- The main body text shall be formatted as follows: **Times New Roman, 12 pt., 1.5 line spacing, justified alignment, black font color**.

- Page margins (without borders or additional inscriptions): **Top – 20 mm; Bottom – 20 mm; Left – 20 mm; Right – 10 mm**.

- Chapters and subchapters shall be numbered with Arabic numerals (e.g., 1, 2, 3; or 1.1, 1.2; or 1.1.1, 1.1.2). Up to three levels are accepted. The Introduction and Conclusions are not numbered and should not include the word Chapter.

- Source code must be formatted in Courier New, 10 pt., single spacing. If the code exceeds 50% of a page, it must be placed in an appendix, with an appropriate reference in the main text.

- Each chapter title must begin on a new page, formatted in uppercase, Times New Roman, bold, 13 pt., centered.

- Subchapter titles must be formatted in Times New Roman, bold, 12 pt., left-aligned.

- Chapter and subchapter titles must not appear at the bottom of a page.

- Paragraphs shall be formatted as follows: justified alignment, with the first line indented 1.25 cm.

- The spacing between a chapter or subchapter title and the subsequent text shall not exceed one line interval.

- A subchapter must cover a minimum of one full page.

- Page numbering shall be placed at the bottom center of each page. The title page and preliminary pages before the Introduction are included in the total page count but shall not display page numbers.

- The report must be printed on A4 paper, single-sided.

- The text must use clear and precise language, presenting information in a direct, intelligible, and logically structured manner. The report must reflect the authors’ original contribution. All bibliographic sources must be cited in-text and listed in the bibliography.

| **Abstract** | A concise summary of your entire report, including: the problem addressed the proposed solution concept main findings and outcomes so far objectives, methods, and anticipated impact |
| --- | --- |
| **Introduction** | Context and background of the problem Motivation and relevance of the project Potential impact on the target audience/market Brief outline of the report structure |
| **Domain Analysis** | Problem Overview: Define the issue, its significance, and the broader context. Target Audience: Identify who will use the application, their needs, and potential benefits. Use data (interviews, surveys, questionnaires) where possible. Solution Concept: Describe the application, its purpose, and main features. Market Research: Compare your idea with existing solutions, identify gaps, and explain how your project improves or innovates. |
| **System Design** | **Technical Requirements** Functional Requirements: core features and operations. Non-Functional Requirements: performance, usability, and security standards. **Behavioral Modeling (UML)** Use Case Diagrams (system-user interactions). Sequence Diagrams (order of operations). **Structural Modeling (UML)** Class or Component Diagrams (system architecture and relationships). |
| **Conclusions** | Summary of findings from Domain Analysis and System Design Achievements and challenges addressed so far Next steps for further development in the PBL course Early considerations for implementation |
| **Bibliography** | Include all sources cited in the report (articles, books, research papers, websites) |
| **Final ****n****otes** | This template is flexible; adapt it to your project needs while keeping the **key sections intact**. Students may use the **LaTeX template provided**, already adapted to the required standards. This is optional, but highly recommended for those wishing to learn a professional tool for academic writing. Total length: **2****5****–****30**** pages**. |

**Enumeration in context**

If the text includes simple lists, they are marked with dashes. Each item begins with a lowercase letter, and each line ends with a semicolon; a period is placed after the final item.

*Example:*

- ….. one;

- ….. two;

- ….. three.

If the list is referenced in the text, enumeration is done using lowercase Latin letters followed by a closing parenthesis.

If multiple levels of enumeration are needed, lowercase *Latin letters *followed by a closing parenthesis are used for the first level, and *Arabic numerals* with a closing parenthesis are used for the secondary level.

*Example:*

- ______________;

- ______________;

- ______________;

- ___________;

- ___________;

- ______________;

- ______________.

Use of any other symbols is prohibited.

*Each item in a list must not exceed one sentence in length.*

**Figures**

Figures must be numbered sequentially within each chapter: the first digit indicates the chapter number, and the second digit represents the order of the figure within that chapter, formatted as “Figure 1.1”.

Both the word “Figure 1.1” and its title should be centered on the page, written in bold, without a period at the end.

If a figure takes more than 75% of the page’s space, it must be included in an appendix, with a reference made to it in the main text.

Figures may be formatted in landscape orientation if necessary, provided they are listed in the Appendix and referenced in the main body of the thesis.

Every figure should be cited within the text and placed immediately following its first reference.

*Example:*

According to Figure 1.1...

**Figure 1.1 – Figure title**

Figures are numbered sequentially regardless of subchapters. Figure titles must not be positioned at the bottom of the page.

**Tables**

Tables are numbered consecutively within each chapter, where the first number represents the chapter and the second number indicates the table’s sequence in that chapter, for example, “Table 1.1.”

Table titles are positioned above the tables and aligned to the right. The content within the tables is formatted using an 11pt font size with single line spacing.

Tables may be presented in landscape orientation if necessary, provided they are included in the Appendix and referenced accordingly in the text.

If a table takes up more than 75% of a page, it should be placed in an appendix, with a corresponding reference made in the main text.

Every table must be cited in the text, and the table itself should appear immediately following its first citation.

*Example:*

As shown in Table 1.1, it is recommended that...

**Table 1.1 – Table title**

| **A** | **B** | **C** | **D** |
| --- | --- | --- | --- |
| 123 | 125 | 255411 | 553321 |
| 123569 | 2548 | 123355 | 1233 |

**Table continuation**

When a table continues on the next page, the title should be placed on the right side, followed by the phrase “Continuation of table 1.1”, also aligned to the right.

*Example:*

**Continuation of table 1.1**

| **A** | **B** | **C** | **D** |
| --- | --- | --- | --- |
| 1235555 | 12588 | 25541188 | 55332188 |
| 1235696778 | 25488 | 12335588 | 123388 |

When a table extends over two or more pages, the column headers must be repeated at the top of each page. 

Table titles should not appear at the bottom of the page.

**Formulas**

Formulas must be numbered using *Arabic numerals* in ascending order within each chapter.

The first digit indicates the chapter number, while the second represents the formula's sequence within that chapter (e.g., (1.1), (1.2), etc.). Formulas should be centered on the page, with the numbering placed at the right margin of the line.

All symbols and coefficients used in a formula must be explained directly below it, in the same order as they appear in the expression.

Each formula must be referenced in the main text, and it should be inserted immediately after its first citation.

*Example:*

According to formula (1.1), the following calculation is performed...

*                                     Ax+B=C                                      (1.1)*

**Appendices**

All appendices must be referenced within the main body of the thesis or project and listed in sequential order (e.g., Appendix A, Appendix B, etc.). Each appendix should start on a new page and include a title centred beneath the heading “Appendix.”

Figures, tables, and formulas included in the appendices should be numbered using the corresponding appendix letter, for example: Figure A1, Table B1, Formula C1.

If an appendix contains only one figure or table, its title may serve as the title of the appendix itself.

*Example:*

**Appendix A**

**Title of the Appendix**

**Table A.1-Table title **

|  |  |  |
| --- | --- | --- |
|  |  |  |

**Figure A.1- Figure title**

**References**

The list of references must follow the order in which the sources are first cited in the text. Each citation is marked using square brackets: for example, [1], and corresponds to a full entry in the reference list. This citation style allows the reader to easily identify the original source of a quoted idea or statement.

Numbers assigned to sources remain consistent throughout the document. If only a specific section or page is referenced, the page number should be included in the citation, e.g., [8, p. 231].

The bibliography in the thesis must be compiled using the Zotero application ([https://www.zotero.org/](https://www.zotero.org/)), following the IEEE citation style.