> Source: Text transcription of report_evaluation_rubric.png (the original image is kept alongside this file). Referenced in Internship_Report_writing_guidelines.md as "the evaluation rubric below."

# Internship Report – Evaluation Rubric

| Criterion | Weight | 10 – excellent | 9 – very good | 8 – good | 7 – satisfactory | 6 – acceptable | 5 – poor | 4 – unacceptable |
|---|---|---|---|---|---|---|---|---|
| **Formatting & template compliance** | 2 pts | Fully follows template and all formatting rules. | Only 1–2 minor deviations. | A few inconsistencies but overall acceptable. | Several noticeable deviations. | Significant issues, but some rules respected. | Most formatting/template rules ignored. | Template not followed at all. |
| **Structure & organization** | 2 pts | Clear, logical, coherent structure throughout. | Mostly logical with small weaknesses. | Generally coherent, some gaps. | Uneven, but still understandable. | Weak, lacks clear flow. | Disorganized, confusing. | Incoherent or missing essential sections. |
| **Citations & references** | 2 pts | All sources correctly cited and listed. | Minor citation/reference errors. | Some inconsistencies, but adequate. | Incomplete or irregular citations. | Major citation gaps, bibliography weak. | Very few sources cited, many errors. | No citations, bibliography absent. |
| **Original contribution** | 2 pts | Strong, evident original work and reflection. | High level of originality with small gaps. | Some originality, but relies on others. | Limited originality, surface-level. | Minimal originality, mostly descriptive. | Very weak, largely copied/paraphrased. | No original input. |
| **Language & clarity** | 2 pts | Precise, formal, error-free. | Clear, with a few minor errors. | Understandable, but some errors. | Frequent mistakes, occasionally unclear. | Limited clarity, errors affect readability. | Weak, many errors, difficult to follow. | Numerous errors, incomprehensible. |

Total weight shown: 5 criteria × 2 pts = 10 pts.
